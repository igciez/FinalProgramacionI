#ifndef INFORME_H_INCLUDED
#define INFORME_H_INCLUDED

int informe_imprimirLista(ArrayList* listaDeposito);
int informe_escribirArchivo(ArrayList* deposito, char* fileName);

#endif // INFORME_H_INCLUDED
