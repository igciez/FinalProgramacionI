#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED

int parser_cargarDepositos(ArrayList* listaDeposito, char* filename);

#endif // PARSER_H_INCLUDED
