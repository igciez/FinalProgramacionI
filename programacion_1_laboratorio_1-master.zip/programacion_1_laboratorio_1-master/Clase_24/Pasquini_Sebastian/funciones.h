#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

int funciones_moverProductos(ArrayList* deposito1, ArrayList* deposito2);
int funciones_descontarProductosDeDeposito(ArrayList* deposito1, ArrayList* deposito2);
int funciones_agregarProductosDeDeposito(ArrayList* deposito1, ArrayList* deposito2);

#endif // FUNCIONES_H_INCLUDED
