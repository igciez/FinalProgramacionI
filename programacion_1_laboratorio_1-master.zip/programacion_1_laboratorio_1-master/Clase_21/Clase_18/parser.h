int parserEmployee(char* fileName , ArrayList* pArrayListEmployee);
