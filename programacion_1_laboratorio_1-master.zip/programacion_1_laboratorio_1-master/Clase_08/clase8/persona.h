typedef struct
{
    char nombre[50];
    char apellido[50];
    int legajo;
}EPersona;
