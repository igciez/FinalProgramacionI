# Clase 10

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* Matrices.pdf

#### Video tutoriales:

* https://www.youtube.com/watch?v=ykFxRnx0u-A&index=10&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV

### Ejercicio
#### Objetivo:

   And now it's time to play. The Game of Fifteen is a puzzle played
   on a square, two-dimensional board with numbered tiles that slide.
   The goal of this puzzle is to arrange the board's tiles from
   smallest to largest, left to right, top to bottom, with an empty
   space in board's bottom-right corner, as in the below.

        1  2  3

        4  5  6

        7  8  _

   The game will start mixed:

        7  5  3

        6  2  4

        1  8  _

- Version: 0.1 del 06 enero de 2016
- Autor: Mauricio D�vila
- Revisi�n: Ernesto Gigliotti

#### Aspectos a destacar:
*   Utilizaci�n simple de matrices
*   Compresi�n de un ejercicio en ingles.
*   Manejo de fecha y hora.