#ifndef VIEW_H_INCLUDED
#define VIEW_H_INCLUDED

int view_pedirDatosAltaMovie();
int view_modificar();

#endif // VIEW_H_INCLUDED
