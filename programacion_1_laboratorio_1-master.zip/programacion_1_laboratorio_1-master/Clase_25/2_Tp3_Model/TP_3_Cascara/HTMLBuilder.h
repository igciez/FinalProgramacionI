#ifndef HTMLBUILDER_H_INCLUDED
#define HTMLBUILDER_H_INCLUDED

void htmlBuilder_generarPagina(EMovie* movie,char *nombre, int lenPeliculas);

#endif // HTMLBUILDER_H_INCLUDED
