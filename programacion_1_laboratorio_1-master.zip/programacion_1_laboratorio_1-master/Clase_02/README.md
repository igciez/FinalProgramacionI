# Clase 2

### Material

#### Apuntes:

En el directorio "apuntes" se podr�n encontrar los siguientes archivos:
* Primeros_algoritmos.pdf

#### Video tutoriales:

* https://www.youtube.com/watch?v=3BgMxuGO5tI&index=2&list=PLZU3OfSJlsrfKiKElmKxjCsyQQF_1ApuV

### Ejercicio
#### Objetivo:

Realizar un programa que solicite cinco n�meros e imprima por pantalla el promedio, el m�ximo y el m�nimo.

- Version: 0.1 del 29 diciembre de 2015
- Autor: Mauricio D�vila
- Revisi�n: Ernesto Gigliotti

#### Aspectos a destacar:
*   El uso de bucles para pedir un n�mero tras otro
*   El uso de acumuladores, se tiene que guardar la suma para luego hacer el promedio
*   El uso del if para preguntar si el numero ingresado es mayor o menor para guardar los m�ximos y m�nimos